/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

import java.util.Date;

public class Appointment {

// set strings
	final private byte id_length;
	  final private byte description_length;
	  final private String INITIALIZER;
	  private String appointmentId;
	  private Date appointmentDate;
	  private String description;

// set lengths and initalizer
	  {
		id_length = 10;
		description_length = 50;
	    INITIALIZER = "INITIAL";
	  }
// original appointment
	  Appointment() {
	    Date today = new Date();
	    appointmentId = INITIALIZER;
	    appointmentDate = today;
	    description = INITIALIZER;
	  }
//updated appointment ID
	  Appointment(String id) {
	    Date today = new Date();
	    updateAppointmentId(id);
	    appointmentDate = today;
	    description = INITIALIZER;
	  }
//updated appointment ID and date
	  Appointment(String id, Date date) {
	    updateAppointmentId(id);
	    updateDate(date);
	    description = INITIALIZER;
	  }
//updated appointment ID, date and description
	  Appointment(String id, Date date, String description) {
	    updateAppointmentId(id);
	    updateDate(date);
	    updateDescription(description);
	  }
//update appointment ID without it being null or too many characters
	  public void updateAppointmentId(String id) {
	    if (id == null) {
	      throw new IllegalArgumentException("Appointment ID cannot be null.");
	    } else if (id.length() > id_length) {
	      throw new IllegalArgumentException("Appointment ID cannot be more than " + id_length + " characters.");
	    } else {
	      this.appointmentId = id;
	    }
	  }

	  public String getAppointmentId() { return appointmentId; }
	  
	  
// update appointment date without it being null or in the past
	  public void updateDate(Date date) {
	    if (date == null) {
	      throw new IllegalArgumentException("Appointment date cannot be null.");
	    } else if (date.before(new Date())) {
	      throw new IllegalArgumentException("Cannot make appointment in the past.");
	    } else {
	      this.appointmentDate = date;
	    }
	  }

	  public Date getAppointmentDate() { return appointmentDate; }
	  
// update appointment description without being null or too many characters
	  public void updateDescription(String description) {
	    if (description == null) {
	      throw new IllegalArgumentException(
	          "Appointment description cannot be null.");
	    } else if (description.length() > description_length) {
	      throw new IllegalArgumentException(
	          "Appointment description cannot be more than " + description_length + " characters.");
	    } else {
	      this.description = description;
	    }
	  }

	  public String getDescription() { return description; }
	}
