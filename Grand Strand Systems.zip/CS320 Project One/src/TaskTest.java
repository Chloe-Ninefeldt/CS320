/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskTest {
	 private String id, name, description;
	  private String tooLongId, tooLongName, tooLongDescription;

	  @BeforeEach
	  void setUp() {
	    id = "1234567890";
	    name = "Walk Dog";
	    description = "Put leash on dog and walk.";
	    tooLongId = "111222333444555666777888999";
	    tooLongName = "Walk the dog, Walk the dog, Walk the dog, Walk the dog";
	    tooLongDescription = "Put leash on dog. Walk down the stairs. Let dog sniff every single blade of grass. Tell dog he is a good boy. End the walk and go to bed.";
	  }

//test getting task ID
	  @Test
	  void getTaskIdTest() {
	    Task task = new Task(id);
	    Assertions.assertEquals(id, task.getTaskId());
	  }
//test getting task name
	  @Test
	  void getNameTest() {
	    Task task = new Task(id, name);
	    Assertions.assertEquals(name, task.getName());
	  }
//test getting task description
	  @Test
	  void getDescriptionTest() {
	    Task task = new Task(id, name, description);
	    Assertions.assertEquals(description, task.getDescription());
	  }
//test setting task name
	  @Test
	  void setNameTest() {
	    Task task = new Task();
	    task.setName(name);
	    Assertions.assertEquals(name, task.getName());
	  }
//test setting task description
	  @Test
	  void setDescriptionTest() {
	    Task task = new Task();
	    task.setDescription(description);
	    Assertions.assertEquals(description, task.getDescription());
	  }
//test if task ID is too many characters
	  @Test
	  void TaskIdTooLongTest() {
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> new Task(tooLongId));
	  }
//test if task name is too many characters
	  @Test
	  void setTooLongNameTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setName(tooLongName));
	  }
//test if task description is too many characters
	  @Test
	  void setTooLongDescriptionTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setDescription(tooLongDescription));
	  }
//test if task ID is blank/null
	  @Test
	  void TaskIdNullTest() {
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> new Task(null));
	  }
//test if task name is blank/null	  
	  @Test
	  void TaskNameNullTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setName(null));
	  }
//test if task description is blank/null
	  @Test
	  void TaskDescriptionNullTest() {
	    Task task = new Task();
	    Assertions.assertThrows(IllegalArgumentException.class,
	                            () -> task.setDescription(null));
	  }
}
