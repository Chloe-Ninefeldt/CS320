/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;



public class AppointmentServiceTest {
//set strings	
	private String id, description;
	  private String tooLongId, tooLongDescription;
	  private Date date, pastDate;

	  
// put set up  	  
	  @SuppressWarnings("deprecation")
	  @BeforeEach
	  void setUp() {
	    id = "0000000001";
	    description = "Required description.";
	    date = new Date(3021, Calendar.JANUARY, 1);
	    tooLongId = "0000000000000000000000001";
	    tooLongDescription = "Required description.Required description.Required description.Required description.Required description.Required description.Required description..";
	    pastDate = new Date(0);
	  }

//test updating appointment ID	  
	  @Test
	  void testUpdateAppointmentId() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class,
	                 () -> appt.updateAppointmentId(null));
	    assertThrows(IllegalArgumentException.class,
	                 () -> appt.updateAppointmentId(tooLongId));
	    appt.updateAppointmentId(id);
	    assertEquals(id, appt.getAppointmentId());
	  }
	  
//test getting appointment ID	  
	  @Test
	  void testGetAppointmentId() {
	    Appointment appt = new Appointment(id);
	    assertNotNull(appt.getAppointmentId());
	    assertEquals(appt.getAppointmentId().length(), 10);
	    assertEquals(id, appt.getAppointmentId());
	  }

	  
//testing updating date	  
	  @Test
	  void testUpdateDate() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class, () -> appt.updateDate(null));
	    assertThrows(IllegalArgumentException.class,
	                 () -> appt.updateDate(pastDate));
	    appt.updateDate(date);
	    assertEquals(date, appt.getAppointmentDate());
	  }

	  
//testing getting an appointment date	  
	  @Test
	  void testGetAppointmentDate() {
	    Appointment appt = new Appointment(id, date);
	    assertNotNull(appt.getAppointmentDate());
	    assertEquals(date, appt.getAppointmentDate());
	  }

	  
//testing getting a description updated	   
	  @Test
	  void testUpdateDescription() {
	    Appointment appt = new Appointment();
	    assertThrows(IllegalArgumentException.class,
	                 () -> appt.updateDescription(null));
	    assertThrows(IllegalArgumentException.class,
	                 () -> appt.updateDescription(tooLongDescription));
	    appt.updateDescription(description);
	    assertEquals(description, appt.getDescription());
	  }

	  
//testing getting a description	  
	  @Test
	  void testGetDescription() {
	    Appointment appt = new Appointment(id, date, description);
	    assertNotNull(appt.getDescription());
	    assertTrue(appt.getDescription().length() <= 50);
	    assertEquals(description, appt.getDescription());
	  }
}
