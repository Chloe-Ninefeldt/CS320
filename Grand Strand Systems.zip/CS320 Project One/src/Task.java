/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

public class Task {
	 private String taskId;
	  private String name;
	  private String description;
//set initials
	  Task() {
	    taskId = "INITIAL";
	    name = "INITIAL";
	    description = "INITIAL DESCRIPTION";
	  }

	  Task(String taskId) {
	    checkTaskId(taskId);
	    name = "INITIAL";
	    description = "INITIAL DESCRIPTION";
	  }

	  Task(String taskId, String name) {
	    checkTaskId(taskId);
	    setName(name);
	    description = "INITIAL DESCRIPTION";
	  }
	  
	  Task(String taskId, String name, String desc) {
	    checkTaskId(taskId);
	    setName(name);
	    setDescription(desc);
	  }

	  public final String getTaskId() { return taskId; }

	  public final String getName() { return name; }

//make sure task ID is less than 10 characters
	  private void checkTaskId(String taskId) {
	    if (taskId == null || taskId.length() > 10) {
	      throw new IllegalArgumentException("Task Error: please enure input is correct.");
	    } else {
		      this.taskId = taskId;
	    }
		    }

//make sure name is less than 20 characters
	  protected void setName(String name) {
	    if (name == null || name.length() > 20) {
	      throw new IllegalArgumentException("Task name invalid. Ensure input does not exceed 20 characters and not blank.");
	    } else {
	      this.name = name;
	    }
	  }

	  public final String getDescription() { return description; }
//make sure description is less than 50 characters
	  protected void setDescription(String taskDescription) {
	    if (taskDescription == null || taskDescription.length() > 50) {
	      throw new IllegalArgumentException("Task description invalid. Ensure input does not exceed 50 characters and not blank.");
	    } else {
	      this.description = taskDescription;
	    }
	  }


}
