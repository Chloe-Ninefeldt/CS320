/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

import static org.junit.jupiter.api.Assertions.*;

import java.util.Calendar;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentTest {
	private String id, description, tooLongDescription;
	  private Date date, pastDate;
	  
//setting strings and dates
	  @SuppressWarnings("deprecation")
	  @BeforeEach
	  void setUp() {
	    id = "0000000001";
	    description = "Required Description.";
	    date = new Date(3021, Calendar.JANUARY, 1);
	    tooLongDescription = "Required Description.Required Description.Required Description.Required Description.Required Description.Required Description.Required Description.";
	    pastDate = new Date(0);
	  }

	  
//testing that adding a new appointment is done properly	  
	  @Test
	  void testNewAppointment() {
	    AppointmentService service = new AppointmentService();

	    service.newAppointment();
	    assertNotNull(service.getAppointmentList().get(0).getAppointmentId());
	    assertNotNull(service.getAppointmentList().get(0).getAppointmentDate());
	    assertNotNull(service.getAppointmentList().get(0).getDescription());

	    service.newAppointment(date);
	    assertNotNull(service.getAppointmentList().get(1).getAppointmentId());
	    assertEquals(date,service.getAppointmentList().get(1).getAppointmentDate());
	    assertNotNull(service.getAppointmentList().get(1).getDescription());

	    service.newAppointment(date, description);
	    assertNotNull(service.getAppointmentList().get(2).getAppointmentId());
	    assertEquals(date, service.getAppointmentList().get(2).getAppointmentDate());
	    assertEquals(description,service.getAppointmentList().get(2).getDescription());

	    assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), service.getAppointmentList().get(1).getAppointmentId());
	    assertNotEquals(service.getAppointmentList().get(0).getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());
	    assertNotEquals(service.getAppointmentList().get(1).getAppointmentId(), service.getAppointmentList().get(2).getAppointmentId());

	    assertThrows(IllegalArgumentException.class,
	                 () -> service.newAppointment(pastDate));
	    assertThrows(IllegalArgumentException.class,
	                 () -> service.newAppointment(date, tooLongDescription));
	  }

	  
// testing that deleting an appointment is done properly   
	  @Test
	  void deleteAppointment() throws Exception {
	    AppointmentService service = new AppointmentService();

	    service.newAppointment();
	    service.newAppointment();
	    service.newAppointment();

	    String ID1 = service.getAppointmentList().get(0).getAppointmentId();
	    String ID2 = service.getAppointmentList().get(1).getAppointmentId();
	    String ID3 = service.getAppointmentList().get(2).getAppointmentId();

	    assertNotEquals(ID1, ID2);
	    assertNotEquals(ID1, ID3);
	    assertNotEquals(ID2, ID3);
	    assertNotEquals(id, ID1);
	    assertNotEquals(id, ID2);
	    assertNotEquals(id, ID3);

	    assertThrows(Exception.class, () -> service.deleteAppointment(id));

	    service.deleteAppointment(ID1);
	    assertThrows(Exception.class, () -> service.deleteAppointment(ID1));
	    assertNotEquals(ID1,
	                    service.getAppointmentList().get(0).getAppointmentId());
	  }
}
