/*
 * Chloe Ninefeldt
 * CS 320 
 * Project One
 * 08/04/2021
 */

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public class TaskService {
	private final List<Task> taskList = new ArrayList<>();

	  private String newUniqueId() {
	    return UUID.randomUUID().toString().substring(
	        0, Math.min(toString().length(), 10));
	  }
//search for task in list
	  private Task searchForTask(String id) throws Exception {
	    int index = 0;
	    while (index < taskList.size()) {
	      if (id.equals(taskList.get(index).getTaskId())) {
	        return taskList.get(index);
	      }
	      index++;
	    }
	    throw new Exception("Task nonexistant.");
	  }
//new task adds new ID to Task list
	  public void newTask() {
	    Task task = new Task(newUniqueId());
	    taskList.add(task);
	  }
//new task adds new ID and name to task list
	  public void newTask(String name) {
	    Task task = new Task(newUniqueId(), name);
	    taskList.add(task);
	  }
//new taks adds new Id, name, and description to task list
	  public void newTask(String name, String description) {
	    Task task = new Task(newUniqueId(), name, description);
	    taskList.add(task);
	  }
//deleting a task deletes task from task list
	  public void deleteTask(String id) throws Exception {
	    taskList.remove(searchForTask(id));
	  }
//updating name 
	  public void updateName(String id, String name) throws Exception {
	    searchForTask(id).setName(name);
	  }
//updating description
	  public void updateDescription(String id, String description)
	      throws Exception {
	    searchForTask(id).setDescription(description);
	  }

	  public List<Task> getTaskList() { return taskList; }
}
